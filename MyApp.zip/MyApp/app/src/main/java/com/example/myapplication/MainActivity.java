package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Устанавливаем макет activity_main
        setContentView(R.layout.activity_main);

        // Находим кнопку по ID
        Button redButton = findViewById(R.id.redButton);

        // Обработчик нажатия на кнопку
        redButton.setOnClickListener(v -> {
            // Устанавливаем макет welcome_layout
            setContentView(R.layout.welcome_layout);
        });
    }
}
